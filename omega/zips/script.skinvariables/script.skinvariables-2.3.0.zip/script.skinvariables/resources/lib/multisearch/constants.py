# -*- coding: utf-8 -*-
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html


PROPERTY_PREFIX = 'SkinVariables.MultiSearch'
